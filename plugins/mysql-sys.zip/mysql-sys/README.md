# mysql-sys
The MySQL sys schema for PmaControl (working with MariaDB and all MySQL like)
